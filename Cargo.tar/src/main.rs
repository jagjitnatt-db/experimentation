use std::cmp::{max, min};
use csv::Reader;
use std::collections::{HashMap, HashSet};
use std::{cmp, f32, fs};
use std::fs::{File, read_to_string};
use std::hash::Hash;
use std::io::{BufRead, BufReader, Bytes, Lines, Read};
use std::time::SystemTime;

fn main() {
    let start = SystemTime::now();
    let file_location = r"D:\Development\Data\BRC\measurements.txt";
    //let data = read_entire_file(file_location);
    //let data = buffered_read(file_location);
    //let data = buffered_binary_read(file_location);
    //let data = buffered_binary_read_opt(file_location);
    //let data = buffered_binary_dict(file_location);
    //let data = buffered_batch_binary_dict(file_location);
    //let fixed_data = find_mean(data);
    // for (key, value) in &fixed_data {
    //     println!("Key: {}, Value: {:?}", key, value);
    // }

    //let d = read_file_into_chunks(file_location);
    //let d = read_file_csv(file_location);
    //let d = read_lines_from_file(file_location);
    let d = read_multi_lines_from_file(file_location);
    println!("{:?}", d);
    let end = SystemTime::now().duration_since(start).expect("Incorrect Time");
    println!("Total Time - {}", end.as_secs());
}

fn read_entire_file(file_name:&str) -> () {
    let mut line_number:u32 = 0;
    let file = read_to_string(file_name).expect("File not Found");
    let lines = file.lines();
    for line in lines {
        line_number += 1;
    }
    println!("Total Lines Found - {}", line_number);
    ()
}

fn buffered_read(file_name: &str) -> () {
    let buffer_size_mb:usize = 1024 * 1024;
    let mut line_number:u32 = 0;
    let file = File::open(file_name).expect("File not Found");
    let mut reader = BufReader::with_capacity(256 * buffer_size_mb, file);
    let mut file_text = String::new();
    //let lines = reader.lines();

    let mut reader_return = reader.read_line(&mut file_text).expect("File not read");
    while reader_return > 0 {
        line_number += 1;
        file_text.clear();
        reader_return = reader.read_line(&mut file_text).expect("File not read");
    }
    // for line in lines {
    //     line_number += 1;
    // }
    println!("Total Lines Found - {}", line_number);
    return ()
}

fn buffered_binary_read(file_name: &str) -> () {
    let buffer_size_mb:usize = 1024 * 1024;
    let mut line_number:u32 = 0;
    let file = File::open(file_name).expect("File not Found");
    let mut reader = BufReader::with_capacity(256 * buffer_size_mb, file);
    let mut chr_vector:Vec<u8> = vec![];
    let mut reader_return = reader.read_until(10, &mut chr_vector).expect("File not read");
    while reader_return > 0 {
        line_number += 1;
        chr_vector.clear();
        reader_return = reader.read_until(10, &mut chr_vector).expect("File not read");
    }
    println!("Total Lines Found - {}", line_number);
    return ()
}

fn buffered_binary_read_opt(file_name: &str) -> () {
    let buffer_size_mb:usize = 1024 * 1024;
    let mut line_number:usize = 0;
    let file = File::open(file_name).expect("File not Found");
    let mut reader = BufReader::with_capacity(256 * buffer_size_mb, file);
    let mut chr_array: [u8; 131072] = [0;131072];
    let mut reader_return = reader.read(&mut chr_array).expect("File not read");
    while reader_return > 0 {
        line_number += chr_array.into_iter().filter(|&x| filter_function(x)).count();
        chr_array.fill(0);
        reader_return = reader.read(&mut chr_array).expect("File not read");
    }
    println!("Total Lines Found - {}", line_number);
    return ()
}

fn filter_function(x:u8) -> bool {
    return x == 10;
}


fn buffered_binary_dict(file_name: &str) -> HashMap<String, (i32, i32, i32, u32)> {
    let mut city = String::from("sds");
    let mut temp:i32;
    let mut main_dict: HashMap<String, (i32, i32, i32, u32)> = HashMap::new();
    let buffer_size_mb:usize = 1024 * 1024;
    let file = File::open(file_name).expect("File not Found");
    let mut reader = BufReader::with_capacity(256 * buffer_size_mb, file);
    let mut chr_vector:Vec<u8> = vec![];
    let mut reader_return = reader.read_until(10, &mut chr_vector).expect("File not read");
    while reader_return > 0 {
        let vecdata = std::str::from_utf8(&chr_vector).unwrap().strip_suffix("\n").unwrap().to_string();
        let city = vecdata.split(";").nth(0).unwrap().to_string();
        let temp = ((&vecdata.split(";").nth(1).unwrap().to_string().parse::<f32>().unwrap()) * 10.0) as i32;
        if main_dict.contains_key(&city) {
            let current_val:(i32, i32, i32, u32) = main_dict[&city];
            main_dict.insert(city, (min(current_val.0, temp), max(current_val.1, temp), current_val.2 + temp, current_val.3 + 1));
        }
        else{
            main_dict.entry(city).or_insert((temp, temp, temp, 1));
        }
        chr_vector.clear();
        reader_return = reader.read_until(10, &mut chr_vector).expect("File not read");
    }
    return main_dict
}

fn find_mean(dict:HashMap<String, (i32,i32,i32,u32)>) -> HashMap<String, (f32,f32,f32)> {
    let mut ret_dict :HashMap<String, (f32,f32,f32)> = HashMap::new();
    for (key, val) in dict {
        let min = (val.0 as f32) / 10.0;
        let max = (val.1 as f32) / 10.0;
        let mean = ((val.2 as f32) / (val.3 as f32)) / 10.0;
        ret_dict.insert(key, (min, max, mean));
    }
    return ret_dict
}



fn buffered_batch_binary_dict(file_name: &str) -> HashMap<String, (f32, f32, f32, u32)> {
    let mut main_dict: HashMap<String, (f32, f32, f32, u32)> = HashMap::new();
    let record:(String, String);
    let buffer_size_mb:usize = 1024 * 1024;
    let file = File::open(file_name).expect("File not Found");
    let mut reader = BufReader::with_capacity(256 * buffer_size_mb, file);
    let mut chr_vector:Vec<u8> = vec![];
    let mut file_string = String::new();
    let mut reader_return = reader.read_line(&mut file_string).expect("File not read");
    //println!("{}", file_string);
    while reader_return > 0 {
        let clone_string = file_string.clone();
        let splits: Vec<_> = clone_string.strip_suffix("\n").unwrap().split(";").collect();
        let record:(&str, &str) = (splits[0], splits[1]);
        //println!("{:?}", record);
        let city = record.0;
        let temp = record.1.parse::<f32>().expect("Error while converting to Float");
        if main_dict.contains_key(city) {
            let current_val:(f32, f32, f32, u32) = main_dict[city];
            main_dict.insert(city.parse().unwrap(), (f32::min(current_val.0, temp), f32::max(current_val.1, temp), current_val.2 + temp, current_val.3 + 1));
        }
        else{
            main_dict.entry(city.parse().unwrap()).or_insert((temp, temp, temp, 1));
        }
        &file_string.clear();
        reader_return = reader.read_line(&mut file_string).expect("File not read");
        //reader_return = reader.read_until(10, &mut chr_vector).expect("File not read");
    }
    return main_dict
}

fn update_hashmap(hash_map:&mut HashMap<String, (f32, f32, f32, u32)>, key:&str, value:&f32) -> () {
    //Check if value exists
    ()
}

fn read_file_into_chunks(file_name:&str) -> Vec<u8> {
    let mut data :Vec<u8> = Vec::with_capacity(1000);
    let rec_buffer :Vec<u8>  = Vec::new();
    let record:(String, String);
    let mut file_counter: usize = 1;
    let buffer_size_mb:usize = 1024 * 1024;
    let file = File::open(file_name).expect("File not Found");
    let mut reader = BufReader::with_capacity(256 * buffer_size_mb, file);
    let mut chr_array: [u8; 131072] = [0;131072];
    let mut chr_vector:String = String::new();
    while file_counter > 0 {
        file_counter = reader.read(&mut chr_array).expect("Unable to read data from file");

        //data.extend(chr_array)
    }
    return data
}

fn split_into_chunks(data:&[u8], mut buffer: &Vec<u8>) -> () {
    let mut splits:Vec<u8> = Vec::new();
    let data_vector = data.to_vec();
    let (remaining, lines) = data_vector.split(|&x| x == 10).collect::<Vec<_>>().split_last().unwrap().clone();
    //buffer.extend(data.rsplit(|x| x == &10).nth(0).unwrap().to_vec());
    //let lines = data.split(|x| x == &10).collect::<Vec<u8>>();
    //let lines :Vec<_>= data.split(|x| x==&10).collect()[0..-1];
    //let lines = data.iter().rfind();
    //let remaining = data.split(|x| x==&10).collect()[-1];
    // let parsed_lines = lines.map(|x| {
    //     let splits = x.split(|r| r == &59)?;
    //     let key = splits.nth(0);
    //     let value = splits.nth(1);
    //     return (key, value)
    // })?;
}


fn read_file_csv(file_name:&str) -> Vec<u8> {
    let mut data :Vec<u8> = Vec::with_capacity(1000);
    let record:(String, String);
    let mut file_counter: usize = 1;
    let buffer_size_mb:usize = 1024 * 1024;
    let file = File::open(file_name).expect("File not Found");
    let mut csv_reader = csv::ReaderBuilder::new()
        .has_headers(false)
        .delimiter(b';')
        .double_quote(false)
        .escape(Some(b'\\'))
        .flexible(true)
        .comment(Some(b'#'))
        .from_reader(file);
    for line in csv_reader.byte_records() {
        let record = line.unwrap();
        //data.extend(chr_array)
    }
    return data
}
#[derive(Debug)]
struct Metrics {
    min:f32,
    max:f32,
    sum:f32,
    cnt:u32
}

impl Metrics {
    fn insert(&mut self, temp:f32) {
        self.min = f32::min(self.min, temp);
        self.max = f32::max(self.max, temp);
        self.sum = self.sum + temp;
        self.cnt += 1;
    }
    fn new(temp:f32) -> Metrics {
        Metrics {
            min: temp,
            max: temp,
            sum: temp,
            cnt: 1
        }
    }
}

fn read_lines_from_file(file_name:&str) -> HashMap<String, Metrics>{
    let buffer_size_mb:usize = 1024 * 1024;
    let mut main_dict: HashMap<String, Metrics> = HashMap::new();
    let file = File::open(file_name).expect("File not Found");
    let mut reader = BufReader::with_capacity(256 * buffer_size_mb, file);
    let mut chr_vector:String = String::with_capacity(50);
    while reader.read_line(&mut chr_vector).expect("Reading Failed") > 0 {
        let key = chr_vector.split(";").nth(0).unwrap().to_string();
        let val = chr_vector.strip_suffix("\n").unwrap().split(";").nth(1).unwrap().parse::<f32>().unwrap();
        main_dict.entry(key).and_modify(|v| v.insert(val)).or_insert(Metrics::new(val));
        chr_vector.clear();
    }
    return main_dict
}


fn read_multi_lines_from_file(file_name:&str) -> HashMap<String, Metrics>{
    let mut cntr:u32 = 0;
    let buffer_size_mb:usize = 1024 * 1024;
    let mut main_dict: HashMap<String, Metrics> = HashMap::new();
    let file = File::open(file_name).expect("File not Found");
    let mut reader = BufReader::with_capacity(256 * buffer_size_mb, file);
    let mut chr_vector:String = String::with_capacity(256 * buffer_size_mb);
    while reader.read_line(&mut chr_vector).expect("Reading Failed") > 0 {
        if cntr == 10000000 {
            let data  = chr_vector.lines();
            for line in data {
                let key = line.split(";").nth(0).unwrap().to_string();
                let val = line.split(";").nth(1).expect(line).parse::<f32>().unwrap();
                main_dict.entry(key).and_modify(|v| v.insert(val)).or_insert(Metrics::new(val));
            }
            // let data :Vec<_>= chr_vector.lines().collect::<Vec<_>>();
            // for rec in data.iter().filter(|x| !x.is_empty()) {
            //     let key = rec.split(";").nth(0).unwrap().to_string();
            //     let val = rec.split(";").nth(1).expect(rec).parse::<f32>().unwrap();
            //     main_dict.entry(key).and_modify(|v| v.insert(val)).or_insert(Metrics::new(val));
            // }
            chr_vector.clear();
            cntr = 0;
        }
        cntr += 1;
    }
    return main_dict
}