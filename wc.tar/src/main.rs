use std::cmp::min;
use std::time;
use std::env::args;
use std::fs::File;
use std::io::{BufRead, BufReader, Read, Seek, SeekFrom};
use std::process::exit;
use std::time::SystemTime;
use rayon::iter::ParallelIterator;
use rayon::prelude::IntoParallelRefIterator;

fn main() {
    let start = time::SystemTime::now();
    let args:Vec<String>= args().collect();
    if args.len() != 2 {
        println!("Invalid Arguments");
        exit(99)
    }
    let file_name = args.iter().nth(1).unwrap();
    let chunks = get_chunks(file_name);
    let results:Vec<usize> = chunks.par_iter().map(|chunk| {
        get_lines(file_name, *chunk)
    }).collect();
    let file_size:usize = results.iter().sum();

    println!("{file_size}");
    let end = SystemTime::now().duration_since(start).expect("Incorrect Time");
    println!("Total Time - {} ms", end.as_millis());
}

fn get_chunks2(file_name:&String) -> Vec<(u64, u64)> {
    let cpu_cores:usize = num_cpus::get();
    let file = File::open(file_name).expect("Unable to open file");
    let file_meta = file.metadata().expect("Can't read file size");
    let file_size = file_meta.len();
    let per_core_read:usize = file_size as usize / cpu_cores;
    let chunks:Vec<(u64, u64)> = (0..file_size).step_by(per_core_read).map(|x| (x, min(x + per_core_read as u64 - 1, file_size))).collect();
    chunks
}

fn get_chunks(file_name:&String) -> Vec<(u64, u64)> {
    let chunk_size:u64 = 1000000;
    let mut chunk:u64=0;
    let mut chunks:Vec<(u64,u64)> = Vec::new();
    let file = File::open(file_name).expect("Unable to open file");
    let file_meta = file.metadata().expect("Can't read file size");
    let file_size = file_meta.len();
    while chunk < file_size + 1 {
        chunks.push((chunk, min(chunk + chunk_size, file_size)));
        chunk += chunk_size;
    }
    chunks
}

fn get_lines2(file_name:&String, chunk:(u64,u64)) -> usize {
    let mut buffer_vector:Vec<u8> = Vec::with_capacity(1000000);
    let mut counter:usize = 0;
    let file = File::open(file_name).expect("Unable to open file");
    let mut reader = BufReader::new(file);
    reader.seek(SeekFrom::Start(chunk.0)).expect("Couldn't seek to required location");
    let mut current_position:u64;
    while reader.read_until(10, &mut buffer_vector).expect("Can't read file") > 0 {
        current_position = reader.stream_position().unwrap();
        if current_position > chunk.1 {
            break
        }
        counter += 1;
        if buffer_vector.len() > 10000000 {
            buffer_vector.clear();
        }
    }
    counter
}

fn get_lines(file_name:&String, chunk:(u64,u64)) -> usize {
    let mut buffer_array:[u8;1000000] = [0u8;1000000];
    let file = File::open(file_name).expect("Unable to open file");
    let mut reader = BufReader::new(file);
    reader.seek(SeekFrom::Start(chunk.0)).expect("Couldn't seek to required location");
    let bytes = reader.read(&mut buffer_array).expect("Couldn't read file");
    let counter = buffer_array.iter().filter(|x| **x == 10).count();
    counter
}