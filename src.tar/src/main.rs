use std::cmp::min;
use std::collections::HashMap;
use std::fs::File;
use std::io::{BufRead, BufReader, Read, Seek, SeekFrom};
use std::time::SystemTime;
use std::thread;
use rayon::prelude::*;
use futures::task::SpawnExt;

fn main() {
    let start = SystemTime::now();
    let file_location = r"D:\Development\Data\BRC\measurements.txt";
    let num_threads:usize = 4;
    let chunk_size :u64 = 16000000;
    let chunks = get_chunks(file_location, chunk_size);
    //let mut handles = Vec::new();
    let results: Vec<HashMap<String, Metrics>> = chunks.par_iter().map(|chunk| {
        process_chunk(file_location, *chunk)
    }).collect();

    let final_result = combine_results(results);

    // let total_chunks = chunks.len();
    // for batch in (0..total_chunks).step_by(num_threads){
    //     for c in chunks.iter()[batch..batch+num_threads]{
    //         println!("{}",c);
    //     }
    // }
    // println!("{:?}", chunks[0]);
    // let mut handles = Vec::new();
    // for chunk in chunks{
    //     let handle = thread::spawn(move || {
    //         process_chunk(file_location, chunk)
    //     });
    //     handles.push(handle);
    // }
    //
    // for handle in handles {
    //     println!("{:?}", handle.join().unwrap().get("Bangui").unwrap());
    // }
    //let results = chunks.iter().map(|chunk| process_chunk(file_location, chunk)).collect();
    // for chunk in chunks{
    //     process_chunk(file_location, chunk);
    // }
    // let results = process_chunk(file_location, d[0]);
    //
    println!("{:?}", final_result.len());
    println!("{:?}", final_result);
    let end = SystemTime::now().duration_since(start).expect("Incorrect Time");
    println!("Total Time - {}", end.as_millis());
}

#[derive(Debug)]
struct Metrics {
    min:f32,
    max:f32,
    sum:f32,
    cnt:u32
}

#[derive(Debug)]
struct Results {
    min:f32,
    max:f32,
    mean:f32
}

impl Results {
    fn new(metrics: &Metrics) -> Results {
        Results {
            min: metrics.min,
            max: metrics.max,
            mean: (metrics.sum / metrics.cnt as f32)
        }
    }
}

impl Metrics {
    fn insert(&mut self, metrics: &Metrics) {
        self.min = f32::min(self.min, metrics.min);
        self.max = f32::max(self.max, metrics.max);
        self.sum += metrics.sum;
        self.cnt += metrics.cnt;
    }
    fn new(min_temp:f32, max_temp:f32, sum_temp:f32, cnt_temp:u32) -> Metrics {
        Metrics {
            min: min_temp,
            max: max_temp,
            sum: sum_temp,
            cnt: cnt_temp
        }
    }
}

fn combine_results(results:Vec<HashMap<String, Metrics>>) -> HashMap<String, Results> {
    let mut inter_map:HashMap<String, Metrics> = HashMap::new();
    let mut final_map:HashMap<String, Results> = HashMap::new();
    for result in results{
        for entry in result.into_iter(){
            let city:String = entry.0;
            let metrics:&Metrics = &entry.1;
            inter_map.entry(city).and_modify(|x| x.insert(metrics)).or_insert(Metrics::new(metrics.min, metrics.max, metrics.sum, metrics.cnt));
        }
    }
    for entry in inter_map.into_iter(){
        let city:String = entry.0;
        let metrics:&Metrics = &entry.1;
        final_map.entry(city).or_insert(Results::new(metrics));
    }
    return final_map
}


fn get_chunks(file_name: &str, chunk_size: u64) -> Vec<[u64; 2]> {
    let f = File::open(file_name).expect("File unable to open");
    let mut f2 = File::open(file_name).expect("File unable to open");
    let mut b = BufReader::new(f);
    let metadata = f2.metadata().expect("Unable to get metadata");
    let file_size = metadata.len();
    let mut counter = 0;
    let mut v_chunks :Vec<[u64; 2]> = Vec::new();
    b.seek(SeekFrom::Start(0));
    while counter < file_size{
        let initial_pos = b.stream_position().unwrap();
        let step = min(file_size - initial_pos, chunk_size);
        b.seek(SeekFrom::Current(step as i64)).expect("Failed to Seek to initial position");
        b.read_until(10, &mut vec![]).expect("Failed to Seek to find new line");
        let current_pos = b.stream_position().unwrap() - 1;
        v_chunks.push([initial_pos, current_pos]);
        counter = current_pos + 1;
    }
    return v_chunks
}

fn process_chunk(file_name:&str, chunk: [u64; 2]) -> HashMap<String, Metrics> {
    let start = chunk[0];
    let end = chunk[1];
    let chunk_size = (end - start)  as usize;
    let mut chr_vector: Vec<u8> = vec![0u8;chunk_size];
    let mut metrics:Metrics;
    let mut local_map:HashMap<&str, Vec<f32>> = HashMap::with_capacity(300);
    let mut final_map:HashMap<String, Metrics> = HashMap::with_capacity(300);
    let mut f = File::open(file_name).expect("File unable to open");
    f.seek(SeekFrom::Start(start)).expect("Failed to seek to starting position");
    f.read_exact(&mut chr_vector).expect("Failed to read chunk");
    let binding = String::from_utf8(chr_vector).unwrap();
    let records = binding.lines();
    for record in records{
        let city = record.split(";").nth(0).unwrap();
        let temp = record.split(";").nth(1).unwrap().parse::<f32>().unwrap();
        local_map.entry(city).and_modify(|x| x.push(temp)).or_insert(vec![temp]);
    }
    for item in local_map{
        let city = item.0.to_string();
        let temps = item.1;
        let max_v = temps.iter().copied().reduce(f32::max).expect("Failed to agg");
        let min_v = temps.iter().copied().reduce(f32::min).expect("Failed to agg");
        let sum_v = temps.iter().sum();
        let cnt_v = temps.len() as u32;
        metrics = Metrics::new(min_v, max_v, sum_v, cnt_v);
        final_map.insert(city, metrics);
    }
    return final_map
}